#Highest and lowest performer
n=int(input("No.of students        :"))
English_marks=[]
Mathematics_marks=[]
Science_marks=[]
Highest_total=float("-inf")
Highest_student=""
Lowest_total=float("inf")
Lowest_student=""


total_passed=0

for i in range(1,n+1):
    print(f"Student No    :{i}")
    English=int(input("English     :"))
    Mathematics=int(input("Mathematics :"))
    Science=int(input("Science     :"))
    English_marks.append(English)
    Mathematics_marks.append(Mathematics)
    Science_marks.append(Science)
    total_marks=English+Mathematics+Science



#calculate average marks
    num_subjects=3
    average_marks=total_marks/num_subjects


#track highest performer
    if total_marks>Highest_total:
        Highest_total=total_marks
        Highest_student=f"Student {i}"

#track Lowest performer
    if total_marks<Lowest_total:
        Lowest_total=total_marks
        Lowest_student=f"Student {i}"


#assign grade
    if average_marks>90 and average_marks<=100:
        Grade="A"
    elif average_marks>80 and average_marks<=89:
      Grade="B"
    elif average_marks>70 and average_marks<=79:
        Grade="C"
    elif average_marks>60 and average_marks<=69:
        Grade="D"
    else:
        Grade="E"


    
    

#Pass or fail

    if average_marks>=50 and English>=40 and Mathematics>=40 and Science>=40:
        result="Pass" 
        total_passed+=1   
    else:
        result="Fail"
print(f"Total passed      :{total_passed}")
print(f"English Marks     :{English_marks}")
print(f"Mathematics Marks :{Mathematics_marks}")
print(f"Science Marks     :{Science_marks}")



print(f"Highest Performer :{Highest_student} with {Highest_total} marks")
print(f"Lowest Performer  :{Lowest_student} with {Lowest_total} marks")

    
