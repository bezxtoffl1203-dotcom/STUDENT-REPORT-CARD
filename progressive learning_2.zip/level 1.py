#calculate total marks
English=int(input("English     :"))
Mathematics=int(input("Mathematics :"))
Science=int(input("Science     :"))
total_marks=English+Mathematics+Science
print("Total Marks :",total_marks)