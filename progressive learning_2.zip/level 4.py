#calculate total marks
English=int(input("English     :"))
Mathematics=int(input("Mathematics :"))
Science=int(input("Science     :"))
total_marks=English+Mathematics+Science



#calculate average marks
num_subjects=3
average_marks=total_marks/num_subjects


#assign grade
if average_marks>90 and average_marks<=100:
    Grade="A"
elif average_marks>80 and average_marks<=89:
    Grade="B"
elif average_marks>70 and average_marks<=79:
    Grade="C"
elif average_marks>60 and average_marks<=69:
    Grade="D"
else:
    Grade="E"


    
print(f"Total Marks :{total_marks}")
print(f"Average     :{average_marks:.2f}")
print(f"Grade       :{Grade}")


#Pass or fail

if average_marks>=50 and English>=40 and Mathematics>=40 and Science>=40:
    result="Pass"    
else:
    result="Fail"
print(f"Result     :{result}") 