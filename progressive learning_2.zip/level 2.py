#calculate average marks
English=int(input("English     :"))
Mathematics=int(input("Mathematics :"))
Science=int(input("Science     :"))
total_marks=English+Mathematics+Science
num_subjects=3
average_marks=total_marks/num_subjects
print(f"Total Marks :{total_marks}")
print(f"Average     :{average_marks:.2f}")