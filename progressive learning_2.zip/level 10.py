n=int(input("No.of students        :"))
students=[]
English_marks=[]
Mathematics_marks=[]
Science_marks=[]
student_totals=[]
Highest_total=float("-inf")
Highest_student=""
Lowest_total=float("inf")
Lowest_student=""


total_passed=0
total_failed=0

for i in range(1,n+1):
    print(f"Student No    :{i}")
    name=input("Student name :")
    English=int(input("English     :"))
    Mathematics=int(input("Mathematics :"))
    Science=int(input("Science     :"))
    English_marks.append(English)
    Mathematics_marks.append(Mathematics)
    Science_marks.append(Science)
    total_marks=English+Mathematics+Science
    student_totals.append(total_marks)



#calculate average marks
    num_subjects=3
    average_marks=total_marks/num_subjects


#track highest performer
    if total_marks>Highest_total:
        Highest_total=total_marks
        
        Highest_student=name

#track Lowest performer
    if total_marks<Lowest_total:
        Lowest_total=total_marks
        Lowest_student=name



                      
#assign grade
    if average_marks>90 and average_marks<=100:
        Grade="A"
    elif average_marks>80 and average_marks<=89:
      Grade="B"
    elif average_marks>70 and average_marks<=79:
        Grade="C"
    elif average_marks>60 and average_marks<=69:
        Grade="D"
    else:
        Grade="E"



    
    

#Pass or fail

    if average_marks>=50 and English>=40 and Mathematics>=40 and Science>=40:
        result="Pass" 
        total_passed+=1   
    else:
        result="Fail"
        total_failed+=1



#store full record
    students.append({
        "NUM":i,
        "NAME":name,
        "ENGLISH":English,
        "MATHEMATICS":Mathematics,
        "SCIENCE":Science,
        "TOTAL":total_marks,
        "AVERAGE":average_marks,
        "GRADE":Grade,
        "RESULT":result
    })



















class_average=sum(student_totals)/n

above_average=0
below_average=0

for t in student_totals:
    if t >class_average:
        above_average+=1
    elif t <class_average:
        below_average+=1

for i,t in enumerate(student_totals,1):
    print(f"Student {i} {t}")




print(f"Total passed      :{total_passed}")
print(f"English Marks     :{English_marks}")
print(f"Mathematics Marks :{Mathematics_marks}")
print(f"Science Marks     :{Science_marks}")



print(f"Class Average  : {class_average}")
print(f"Above Class Average  :{above_average}")
print(f"Below Class Average  :{below_average}")



print(f"Passed  : {total_passed}")
print(f"Failed  : {total_failed}")



print(f"Highest Performer :{Highest_student} with {Highest_total} marks")
print(f"Lowest Performer  :{Lowest_student} with {Lowest_total} marks")





#subject wise peformance summary

english_total=sum(English_marks)
english_average=english_total/n
english_high=max(English_marks)
english_low=min(English_marks)


math_total=sum(Mathematics_marks)
math_average=math_total/n
math_high=max(Mathematics_marks)
math_low=min(Mathematics_marks)

sci_total=sum(Science_marks)
sci_average=sci_total/n
sci_high=max(Science_marks)
sci_low=min(Science_marks)


print("Subject-Wise Summary")
print("English")
print(f"Total   : {english_total}")
print(f"Average :  {english_average}")
print(f"Highest : {english_high}")
print(f"Lowest  : {english_low}")



print("Mathematics")
print(f"Total   : {math_total}")
print(f"Average : {math_average}")
print(f"Highest : {math_high}")
print(f"Lowest  : {math_low}")



print("Science")
print(f"Total  : {sci_total}")
print(f"Average : {sci_average}")
print(f"Highest : {sci_high}")
print(f"Lowest  : {sci_low}")